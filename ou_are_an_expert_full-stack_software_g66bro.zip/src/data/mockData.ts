export interface Place {
  id: string;
  name: string;
  category: string;
  neighborhood: string;
  description: string;
  priceRange: string;
  avgPrice: number;
  vibe: string[];
  romanticScore: number;
  firstDateScore: number;
  reservationNeeded: boolean;
  noiseLevel: string;
  googleRating: number;
  address: string;
  tags: string[];
}

export interface Event {
  id: string;
  title: string;
  category: string;
  date: string;
  time: string;
  location: string;
  description: string;
  price: string;
  attendees: number;
}

export interface Guide {
  id: string;
  title: string;
  category: string;
  excerpt: string;
  readTime: string;
}

export const places: Place[] = [
  {
    id: '1',
    name: 'Café Largo',
    category: 'Coffee',
    neighborhood: 'Chiado',
    description: 'Intimate café with outdoor seating overlooking a beautiful square. Perfect for afternoon dates.',
    priceRange: '€',
    avgPrice: 8,
    vibe: ['Cozy', 'Romantic', 'Quiet'],
    romanticScore: 8.5,
    firstDateScore: 9.2,
    reservationNeeded: false,
    noiseLevel: 'Low',
    googleRating: 4.6,
    address: 'Largo do Carmo, Chiado',
    tags: ['coffee', 'outdoor', 'romantic', 'budget-friendly', 'afternoon']
  },
  {
    id: '2',
    name: 'Park Rooftop Bar',
    category: 'Cocktail Bars',
    neighborhood: 'Bairro Alto',
    description: 'Stunning rooftop bar with panoramic views of Lisbon. Best sunset spot in the city.',
    priceRange: '€€',
    avgPrice: 14,
    vibe: ['Trendy', 'Views', 'Sunset'],
    romanticScore: 9.5,
    firstDateScore: 8.8,
    reservationNeeded: true,
    noiseLevel: 'High',
    googleRating: 4.4,
    address: 'Calçada do Combro, Bairro Alto',
    tags: ['rooftop', 'sunset', 'views', 'cocktails', 'romantic']
  },
  {
    id: '3',
    name: 'Ponto Final',
    category: 'Restaurants',
    neighborhood: 'Almada',
    description: 'Waterfront restaurant with stunning river views. Perfect for special occasions.',
    priceRange: '€€€',
    avgPrice: 45,
    vibe: ['Upscale', 'Waterfront', 'Romantic'],
    romanticScore: 9.8,
    firstDateScore: 7.5,
    reservationNeeded: true,
    noiseLevel: 'Medium',
    googleRating: 4.7,
    address: 'Cais do Ginjal, Almada',
    tags: ['seafood', 'waterfront', 'romantic', 'upscale', 'views']
  },
  {
    id: '4',
    name: 'Hello, Kristof',
    category: 'Wine',
    neighborhood: 'Cais do Sodré',
    description: 'Natural wine bar with a relaxed atmosphere. Great for conversation.',
    priceRange: '€€',
    avgPrice: 12,
    vibe: ['Intimate', 'Wine', 'Conversation'],
    romanticScore: 8.8,
    firstDateScore: 9.0,
    reservationNeeded: false,
    noiseLevel: 'Medium',
    googleRating: 4.5,
    address: 'Rua da Boavista, Cais do Sodré',
    tags: ['wine', 'natural wine', 'intimate', 'conversation']
  },
  {
    id: '5',
    name: 'Praia do Guincho',
    category: 'Beach',
    neighborhood: 'Cascais',
    description: 'Beautiful beach with dramatic scenery. Great for adventurous dates.',
    priceRange: 'Free',
    avgPrice: 0,
    vibe: ['Adventurous', 'Natural', 'Active'],
    romanticScore: 9.0,
    firstDateScore: 7.8,
    reservationNeeded: false,
    noiseLevel: 'Variable',
    googleRating: 4.8,
    address: 'Guincho Beach, Cascais',
    tags: ['beach', 'nature', 'surfing', 'sunset', 'adventure']
  },
  {
    id: '6',
    name: 'Bairro do Avillez',
    category: 'Restaurants',
    neighborhood: 'Chiado',
    description: 'Trendy food hall by celebrity chef José Avillez. Fun and casual.',
    priceRange: '€€',
    avgPrice: 25,
    vibe: ['Lively', 'Foodie', 'Fun'],
    romanticScore: 7.5,
    firstDateScore: 8.5,
    reservationNeeded: true,
    noiseLevel: 'High',
    googleRating: 4.3,
    address: 'Rua Nova da Trindade, Chiado',
    tags: ['portuguese', 'food hall', 'lively', 'casual']
  },
  {
    id: '7',
    name: 'Miradouro de Santa Catarina',
    category: 'Viewpoints',
    neighborhood: 'Bica',
    description: 'Stunning viewpoint perfect for sunset watching. Bring wine.',
    priceRange: 'Free',
    avgPrice: 0,
    vibe: ['Romantic', 'Sunset', 'Casual'],
    romanticScore: 9.3,
    firstDateScore: 8.0,
    reservationNeeded: false,
    noiseLevel: 'Medium',
    googleRating: 4.6,
    address: 'Rua de Santa Catarina, Bica',
    tags: ['viewpoint', 'sunset', 'romantic', 'free', 'outdoor']
  },
  {
    id: '8',
    name: 'Second Home',
    category: 'Coworking',
    neighborhood: 'Marvila',
    description: 'Beautiful coworking space with plants everywhere. Great for meeting entrepreneurs.',
    priceRange: '€€',
    avgPrice: 20,
    vibe: ['Professional', 'Creative', 'Social'],
    romanticScore: 5.0,
    firstDateScore: 6.0,
    reservationNeeded: false,
    noiseLevel: 'Low',
    googleRating: 4.7,
    address: 'Rua da Palma, Marvila',
    tags: ['coworking', 'entrepreneurs', 'digital nomads', 'networking']
  }
];

export const events: Event[] = [
  {
    id: '1',
    title: 'Lisbon Language Exchange',
    category: 'Language Exchange',
    date: 'Every Tuesday',
    time: '19:00',
    location: 'Cais do Sodré',
    description: 'Weekly language exchange meetup. Great for meeting locals and expats.',
    price: 'Free',
    attendees: 80
  },
  {
    id: '2',
    title: 'Digital Nomad Meetup',
    category: 'Networking',
    date: 'Every Thursday',
    time: '18:30',
    location: 'Second Home',
    description: 'Connect with fellow digital nomads. Networking and social drinks.',
    price: 'Free',
    attendees: 120
  },
  {
    id: '3',
    title: 'Sunset Rooftop Party',
    category: 'Social',
    date: 'This Saturday',
    time: '17:00',
    location: 'Sky Bar',
    description: 'Weekly sunset party with DJ. Great atmosphere and views.',
    price: '€10',
    attendees: 200
  },
  {
    id: '4',
    title: 'Portuguese Wine Tasting',
    category: 'Experience',
    date: 'Friday',
    time: '18:00',
    location: 'Wine Lounge Chiado',
    description: 'Discover Portuguese wines with a sommelier. Includes cheese pairing.',
    price: '€35',
    attendees: 15
  },
  {
    id: '5',
    title: 'Lisbon Tech Talks',
    category: 'Tech',
    date: 'Monthly',
    time: '19:00',
    location: 'Heden Santa Apolónia',
    description: 'Tech community meetup with speakers and networking.',
    price: 'Free',
    attendees: 150
  }
];

export const guides: Guide[] = [
  {
    id: '1',
    title: 'Portuguese Dating Culture: A Complete Guide',
    category: 'Culture',
    excerpt: 'Understanding how dating works in Portugal, from first dates to relationships.',
    readTime: '8 min'
  },
  {
    id: '2',
    title: 'Best Dating Apps in Portugal 2024',
    category: 'Apps',
    excerpt: 'Tinder, Bumble, Hinge, and local apps compared with success rates.',
    readTime: '5 min'
  },
  {
    id: '3',
    title: 'Common Mistakes Foreigners Make',
    category: 'Advice',
    excerpt: 'Avoid these pitfalls when dating Portuguese people.',
    readTime: '6 min'
  },
  {
    id: '4',
    title: 'First Date Ideas Under €30',
    category: 'Dates',
    excerpt: 'Romantic and creative date ideas that won\'t break the bank.',
    readTime: '4 min'
  },
  {
    id: '5',
    title: 'LGBTQ+ Dating in Lisbon',
    category: 'Community',
    excerpt: 'The best neighborhoods, bars, and communities for LGBTQ+ dating.',
    readTime: '7 min'
  },
  {
    id: '6',
    title: 'Portuguese Flirting Phrases',
    category: 'Language',
    excerpt: 'Essential Portuguese phrases for dating and romance.',
    readTime: '3 min'
  }
];

export const neighborhoods = [
  {
    id: '1',
    name: 'Bairro Alto',
    datingScore: 8.5,
    nightlifeScore: 9.8,
    safetyScore: 7.5,
    nomadScore: 8.0,
    description: 'The heart of Lisbon nightlife. Best for meeting people at bars and clubs.',
    avgPrice: '€€',
    touristRatio: 'High'
  },
  {
    id: '2',
    name: 'Chiado',
    datingScore: 8.8,
    nightlifeScore: 7.0,
    safetyScore: 9.0,
    nomadScore: 8.5,
    description: 'Elegant neighborhood with cafés, restaurants, and cultural venues.',
    avgPrice: '€€€',
    touristRatio: 'High'
  },
  {
    id: '3',
    name: 'Príncipe Real',
    datingScore: 9.0,
    nightlifeScore: 7.5,
    safetyScore: 9.2,
    nomadScore: 9.0,
    description: 'Trendy area with beautiful gardens, boutiques, and great restaurants.',
    avgPrice: '€€€',
    touristRatio: 'Medium'
  },
  {
    id: '4',
    name: 'Alfama',
    datingScore: 7.5,
    nightlifeScore: 6.5,
    safetyScore: 8.5,
    nomadScore: 7.0,
    description: 'Historic neighborhood with Fado houses and romantic viewpoints.',
    avgPrice: '€€',
    touristRatio: 'High'
  },
  {
    id: '5',
    name: 'Cais do Sodré',
    datingScore: 8.2,
    nightlifeScore: 9.0,
    safetyScore: 8.0,
    nomadScore: 8.5,
    description: 'Home to Pink Street. Great mix of bars, restaurants, and transport links.',
    avgPrice: '€€',
    touristRatio: 'High'
  }
];

export const suggestedPrompts = [
  { icon: 'heart', text: 'Best first date ideas under €40', category: 'dates' },
  { icon: 'map', text: 'Where to meet singles in Lisbon', category: 'social' },
  { icon: 'calendar', text: 'Events happening this weekend', category: 'events' },
  { icon: 'wine', text: 'Romantic wine bars for tonight', category: 'places' },
  { icon: 'sun', text: 'Best sunset spots in Lisbon', category: 'places' },
  { icon: 'users', text: 'Digital nomad meetups nearby', category: 'social' },
  { icon: 'coffee', text: 'Quiet cafés for a coffee date', category: 'places' },
  { icon: 'book', text: 'Portuguese dating culture tips', category: 'culture' }
];

export const categories = [
  'All',
  'Coffee',
  'Wine',
  'Cocktail Bars',
  'Restaurants',
  'Viewpoints',
  'Beach',
  'Coworking',
  'Nightlife'
];

export const priceFilters = [
  { label: 'Any Budget', value: 'all' },
  { label: 'Free', value: 'free' },
  { label: 'Budget (€)', value: 'budget' },
  { label: 'Mid (€€)', value: 'mid' },
  { label: 'Upscale (€€€)', value: 'upscale' }
];
