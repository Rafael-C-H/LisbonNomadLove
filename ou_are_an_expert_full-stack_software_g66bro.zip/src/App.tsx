import { useState, createContext, useContext, useEffect } from 'react';
import {
  Heart, MessageCircle, Map, BookOpen, Calendar, Users, Search, Moon, Sun,
  Menu, X, Sparkles, Send, ChevronRight, Star, Clock, Euro, MapPin, Filter,
  Globe, Coffee, Wine, Utensils, Building, Waves, Briefcase, Navigation
} from 'lucide-react';
import { places, events, guides, neighborhoods, suggestedPrompts, categories, priceFilters } from './data/mockData';

// User Context
interface UserPreferences {
  nationality?: string;
  languages?: string[];
  age?: string;
  gender?: string;
  interestedIn?: string;
  relationshipGoals?: string[];
  lengthOfStay?: string;
  budget?: string;
  interests?: string[];
  personality?: string;
  onboardingComplete: boolean;
}

interface UserContextType {
  preferences: UserPreferences;
  setPreferences: (prefs: Partial<UserPreferences>) => void;
  savedPlaces: string[];
  toggleSavePlace: (id: string) => void;
}

const UserContext = createContext<UserContextType | null>(null);

const useUser = () => {
  const context = useContext(UserContext);
  if (!context) throw new Error('useUser must be used within UserProvider');
  return context;
};

// AI Response Generator
const generateAIResponse = (query: string, prefs: UserPreferences): string => {
  const lowerQuery = query.toLowerCase();
  
  if (lowerQuery.includes('first date') || lowerQuery.includes('date idea')) {
    return `Based on your interests, here are some perfect first date ideas in Lisbon:

**For a romantic afternoon:**
Start at **Miradouro de Santa Catarina** around 5pm - it's free, has stunning views, and the sunset is magical. Bring a bottle of wine from a local market.

**For something more active:**
Try a surf lesson at **Praia do Guincho** - it's adventurous, fun, and breaks the ice naturally. Around €40 for a 2-hour lesson including equipment.

**For a classic dinner:**
**Café Largo** in Chiado is intimate and affordable (€15-25 per person). The outdoor seating overlooks a beautiful square.

${prefs.interests?.includes('Wine') ? '\nSince you enjoy wine, I\'d also recommend **Hello, Kristof** for a natural wine tasting experience!' : ''}

Would you like me to help you plan any of these in more detail?`;
  }
  
  if (lowerQuery.includes('meet') && (lowerQuery.includes('people') || lowerQuery.includes('singles'))) {
    return `Great question! Here are the best ways to meet people in Lisbon:

**This Week:**
• **Lisbon Language Exchange** (Tuesday, 7pm) - 80+ attendees, mix of locals and expats
• **Digital Nomad Meetup** (Thursday, 6:30pm) - Perfect for networking

**Regular Spots:**
• **Second Home** (Marvila) - Coworking with a strong community
• **Pink Street** area on weekends - Social bars with a friendly crowd
• **Praça do Comércio** - Join the evening strolls

**Pro Tips:**
1. Portuguese people are friendly but may seem reserved initially
2. Learning a few Portuguese phrases goes a long way
3. Join Facebook groups like "Lisbon Digital Nomads" for more events

Want me to find events matching your specific interests?`;
  }
  
  if (lowerQuery.includes('sunset') || lowerQuery.includes('viewpoint')) {
    return `Lisbon has incredible sunset spots! Here are my top recommendations:

**Most Romantic:**
🌅 **Miradouro de Santa Catarina** - The Adamastor viewpoint. Bring wine, sit on the wall, and watch the sun over the river.

**Best Views:**
🌅 **Miradouro da Senhora do Monte** - Highest viewpoint, 360° views
🌅 **Park Rooftop Bar** - Cocktails with a view (get there by 6pm for a seat)

**Hidden Gem:**
🌅 **Miradouro do Monte da Penha** - Less crowded, beautiful golden hour

**Pro tip:** The best sunsets are from May to September, around 8:30-9pm in summer.

Want directions to any of these?`;
  }
  
  if (lowerQuery.includes('weekend') || lowerQuery.includes('event')) {
    return `Here's what's happening this weekend in Lisbon:

**Friday:**
🍷 Portuguese Wine Tasting at Wine Lounge Chiado (6pm, €35)

**Saturday:**
🎉 Sunset Rooftop Party at Sky Bar (5pm, €10)
🏖️ Beach day at Guincho - great weather predicted

**Sunday:**
🚶‍♂️ Walking tour of Alfama (10am, free)
🛍️ Feira da Ladra flea market (9am-4pm)

**Regular Events:**
• Language Exchange (Tuesday)
• Digital Nomad Meetup (Thursday)

Would you like me to help you plan your weekend itinerary?`;
  }
  
  if (lowerQuery.includes('culture') || lowerQuery.includes('dating') || lowerQuery.includes('portuguese')) {
    return `Here's what you should know about dating in Portugal:

**Portuguese Dating Culture:**
• Portuguese people are generally warm and affectionate
• First dates are often casual - coffee or drinks
• Splitting the bill is becoming more common, but offering to pay is appreciated
• PDA is normal and accepted

**Common Mistakes to Avoid:**
1. Don't be too aggressive - Portuguese appreciate a more subtle approach
2. Don't assume everyone speaks English fluently
3. Don't rush physical intimacy - let things develop naturally
4. Don't be late - punctuality is valued

**Green Flags:**
✅ They introduce you to friends
✅ They want to show you their favorite places
✅ They're curious about your culture

**Red Flags:**
❌ Reluctant to be seen together
❌ Only available late at night
❌ Avoids introducing you to anyone

Want me to explain any of these in more detail?`;
  }
  
  if (lowerQuery.includes('wine') || lowerQuery.includes('bar')) {
    return `Lisbon has an amazing wine scene! Here are my top picks:

**For a Romantic Date:**
🍷 **Hello, Kristof** (Cais do Sodré) - Natural wines, intimate atmosphere
🍷 **By the Wine** (Chiado) - Beautiful cellar, extensive Portuguese selection

**For a Fun Night:**
🍷 **Wine Lounge Chiado** - Tastings with sommelier
🍷 **Quinta do Monte d'Oiro** - Premium Portuguese wines

**Budget-Friendly:**
🍷 **Garrafeira Nacional** - Buy wine and drink at nearby squares

**Pro tip:** Try Vinho Verde (young, slightly sparkling white) - it's perfect for Lisbon's climate and very affordable (€4-6/glass).

Want me to check if any have live music or events tonight?`;
  }
  
  if (lowerQuery.includes('coffee') || lowerQuery.includes('café')) {
    return `Lisbon's coffee scene is thriving! Perfect for casual first dates:

**Most Romantic:**
☕ **Café Largo** (Chiado) - Outdoor seating, beautiful square, €3-4 coffees

**Best for Conversation:**
☕ **Hello, Kristof** - Quiet, intimate, great wine too
☕ **Fábrica Coffee Roasters** - Specialty coffee, relaxed vibe

**Trendy:**
☕ **The Mill** (Rato) - Popular with digital nomads
☕ **Dear Breakfast** - Beautiful interiors, great brunch

**Local Experience:**
☕ **A Brasileira** (Chiado) - Historic café, touristy but iconic

**Pro tip:** Portuguese drink "bica" (espresso) throughout the day. A coffee date here is very normal and won't seem cheap!

Want me to find one near you?`;
  }
  
  return `That's a great question about Lisbon! Let me help you with that.

Based on what I know about the city, I'd recommend checking out some of the places in our directory. The best neighborhoods for meeting people are **Bairro Alto** for nightlife and **Príncipe Real** for a more relaxed vibe.

Would you like me to:
• Find specific places matching your preferences?
• Show you events happening this week?
• Give you more tips about dating culture in Portugal?

Just let me know what interests you most! 💬`;
};

// Onboarding Component
function Onboarding({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState(0);
  const { preferences, setPreferences } = useUser();
  
  const steps = [
    {
      title: 'Welcome to Lisbon Nomad Love',
      subtitle: 'Your AI local friend for dating, social life, and discovering Lisbon',
      question: null,
      field: null
    },
    {
      title: 'Let\'s personalize your experience',
      subtitle: 'This helps me give better recommendations',
      question: 'What are you interested in?',
      field: 'interestedIn',
      options: ['Women', 'Men', 'Everyone', 'Prefer not to say']
    },
    {
      title: 'Relationship goals',
      subtitle: 'What are you looking for?',
      question: null,
      field: 'relationshipGoals',
      options: ['Casual dating', 'Long-term relationship', 'Making friends', 'Just exploring']
    },
    {
      title: 'Your interests',
      subtitle: 'Select all that apply',
      question: null,
      field: 'interests',
      options: ['Coffee', 'Wine', 'Food', 'Nightlife', 'Art', 'Nature', 'Surfing', 'Music', 'Fitness', 'Tech'],
      multi: true
    },
    {
      title: 'How long are you staying?',
      subtitle: 'This helps me recommend the right pace',
      question: null,
      field: 'lengthOfStay',
      options: ['Weekend trip', '1-2 weeks', '1-3 months', 'Living here']
    }
  ];
  
  const currentStep = steps[step];
  
  const handleSelect = (field: string, value: string, multi?: boolean) => {
    if (multi) {
      const current = (preferences as Record<string, string[]>)[field] || [];
      const updated = current.includes(value)
        ? current.filter((v: string) => v !== value)
        : [...current, value];
      setPreferences({ [field]: updated });
    } else {
      setPreferences({ [field]: value });
    }
  };
  
  const handleNext = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      setPreferences({ onboardingComplete: true });
      onComplete();
    }
  };
  
  const handleSkip = () => {
    if (step < steps.length - 1) {
      setStep(step + 1);
    } else {
      setPreferences({ onboardingComplete: true });
      onComplete();
    }
  };
  
  const isMulti = 'multi' in currentStep && currentStep.multi;
  const field = currentStep.field as string | null;
  const currentValue = field ? (preferences as Record<string, unknown>)[field] : null;
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="glass rounded-3xl p-8 max-w-md w-full animate-fade-in-up">
        <div className="text-center mb-8">
          <div className="w-16 h-16 rounded-2xl bg-gradient-to-br from-[var(--accent)] to-pink-400 flex items-center justify-center mx-auto mb-4 animate-float">
            <Heart className="w-8 h-8 text-white" fill="white" />
          </div>
          <h2 className="text-2xl font-bold mb-2">{currentStep.title}</h2>
          <p className="text-[var(--muted)]">{currentStep.subtitle}</p>
        </div>
        
        {currentStep.options && (
          <div className="space-y-3 mb-8">
            {currentStep.options.map((option) => {
              const isSelected = isMulti
                ? Array.isArray(currentValue) && currentValue.includes(option)
                : currentValue === option;
              return (
                <button
                  key={option}
                  onClick={() => handleSelect(field!, option, isMulti)}
                  className={`w-full p-4 rounded-xl text-left transition-all duration-200 ${
                    isSelected
                      ? 'bg-[var(--accent-soft)] border-2 border-[var(--accent)] text-[var(--text)]'
                      : 'bg-[var(--surface)] border border-[var(--border)] text-[var(--text-secondary)] hover:border-[var(--accent)] hover:bg-[var(--card-hover)]'
                  }`}
                >
                  {option}
                </button>
              );
            })}
          </div>
        )}
        
        {step === 0 && (
          <div className="text-center mb-8">
            <p className="text-[var(--text-secondary)] mb-4">
              I'll help you discover the best of Lisbon's dating scene, find amazing places, and connect with the right people.
            </p>
            <p className="text-sm text-[var(--muted)]">
              You can skip any question and change preferences later.
            </p>
          </div>
        )}
        
        <div className="flex gap-3">
          {step > 0 && (
            <button
              onClick={handleSkip}
              className="flex-1 py-3 px-6 rounded-xl border border-[var(--border)] text-[var(--muted)] hover:text-[var(--text)] hover:border-[var(--text-secondary)] transition-colors"
            >
              Skip
            </button>
          )}
          <button
            onClick={handleNext}
            className="flex-1 py-3 px-6 rounded-xl bg-[var(--accent)] text-white font-medium hover:opacity-90 transition-opacity"
          >
            {step === 0 ? "Let's Go" : step === steps.length - 1 ? 'Start Exploring' : 'Continue'}
          </button>
        </div>
        
        <div className="flex justify-center gap-2 mt-6">
          {steps.map((_, i) => (
            <div
              key={i}
              className={`w-2 h-2 rounded-full transition-colors ${
                i === step ? 'bg-[var(--accent)]' : i < step ? 'bg-[var(--accent-soft)]' : 'bg-[var(--border)]'
              }`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

// Chat Component
function Chat() {
  const { preferences } = useUser();
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; content: string }>>([]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  
  const handleSend = (text?: string) => {
    const query = text || input.trim();
    if (!query) return;
    
    setMessages(prev => [...prev, { role: 'user', content: query }]);
    setInput('');
    setIsTyping(true);
    
    setTimeout(() => {
      const response = generateAIResponse(query, preferences);
      setMessages(prev => [...prev, { role: 'assistant', content: response }]);
      setIsTyping(false);
    }, 1000 + Math.random() * 1000);
  };
  
  return (
    <div className="flex flex-col h-[calc(100vh-12rem)]">
      {messages.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center p-8">
          <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-[var(--accent)] to-pink-400 flex items-center justify-center mb-6 animate-pulse-glow">
            <Heart className="w-10 h-10 text-white" fill="white" />
          </div>
          <h2 className="text-2xl font-bold mb-2 text-center">Ask me anything about Lisbon</h2>
          <p className="text-[var(--muted)] text-center mb-8 max-w-md">
            I'm your local AI friend. Ask about dating, places to go, events, or anything else!
          </p>
          
          <div className="grid grid-cols-2 gap-3 w-full max-w-lg">
            {suggestedPrompts.slice(0, 6).map((prompt, i) => (
              <button
                key={i}
                onClick={() => handleSend(prompt.text)}
                className="glass rounded-xl p-4 text-left hover:bg-[var(--card-hover)] transition-all duration-200 group animate-fade-in-up"
                style={{ animationDelay: `${i * 0.05}s` }}
              >
                <span className="text-sm text-[var(--text-secondary)] group-hover:text-[var(--text)] transition-colors">
                  {prompt.text}
                </span>
              </button>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex-1 overflow-y-auto space-y-4 p-4">
          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'} animate-fade-in-up`}
              style={{ animationDelay: `${i * 0.05}s` }}
            >
              <div
                className={`max-w-[80%] rounded-2xl p-4 ${
                  msg.role === 'user'
                    ? 'bg-[var(--accent)] text-white'
                    : 'glass'
                }`}
              >
                <div className="whitespace-pre-wrap text-sm leading-relaxed">{msg.content}</div>
              </div>
            </div>
          ))}
          {isTyping && (
            <div className="flex justify-start animate-fade-in">
              <div className="glass rounded-2xl p-4">
                <div className="typing-indicator">
                  <span></span>
                  <span></span>
                  <span></span>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
      
      <div className="p-4 border-t border-[var(--border)]">
        <div className="flex gap-3 max-w-3xl mx-auto">
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="Ask about dating, places, events..."
            className="flex-1 bg-[var(--surface)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--text)] placeholder:text-[var(--muted)] focus:outline-none focus:border-[var(--accent)] transition-colors"
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim()}
            className="px-4 py-3 bg-[var(--accent)] text-white rounded-xl hover:opacity-90 disabled:opacity-50 disabled:cursor-not-allowed transition-opacity"
          >
            <Send className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
}

// Directory Component
function Directory() {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedPrice, setSelectedPrice] = useState('all');
  const { savedPlaces, toggleSavePlace } = useUser();
  
  const filteredPlaces = places.filter(place => {
    const matchesSearch = place.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      place.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      place.neighborhood.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || place.category === selectedCategory;
    const matchesPrice = selectedPrice === 'all' ||
      (selectedPrice === 'free' && place.priceRange === 'Free') ||
      (selectedPrice === 'budget' && place.priceRange === '€') ||
      (selectedPrice === 'mid' && place.priceRange === '€€') ||
      (selectedPrice === 'upscale' && place.priceRange === '€€€');
    return matchesSearch && matchesCategory && matchesPrice;
  });
  
  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row gap-4">
        <div className="flex-1 relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[var(--muted)]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search places..."
            className="w-full bg-[var(--surface)] border border-[var(--border)] rounded-xl pl-12 pr-4 py-3 text-[var(--text)] placeholder:text-[var(--muted)] focus:outline-none focus:border-[var(--accent)] transition-colors"
          />
        </div>
        <select
          value={selectedPrice}
          onChange={(e) => setSelectedPrice(e.target.value)}
          className="bg-[var(--surface)] border border-[var(--border)] rounded-xl px-4 py-3 text-[var(--text)] focus:outline-none focus:border-[var(--accent)]"
        >
          {priceFilters.map(f => (
            <option key={f.value} value={f.value}>{f.label}</option>
          ))}
        </select>
      </div>
      
      <div className="flex gap-2 overflow-x-auto pb-2 -mx-4 px-4 md:mx-0 md:px-0">
        {categories.map(cat => (
          <button
            key={cat}
            onClick={() => setSelectedCategory(cat)}
            className={`px-4 py-2 rounded-full whitespace-nowrap transition-all ${
              selectedCategory === cat
                ? 'bg-[var(--accent)] text-white'
                : 'bg-[var(--surface)] text-[var(--text-secondary)] hover:bg-[var(--card-hover)]'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredPlaces.map((place, i) => (
          <div
            key={place.id}
            className="glass rounded-2xl p-5 hover:bg-[var(--card-hover)] transition-all duration-200 group animate-fade-in-up"
            style={{ animationDelay: `${i * 0.05}s` }}
          >
            <div className="flex items-start justify-between mb-3">
              <div>
                <h3 className="font-semibold text-lg group-hover:text-[var(--accent)] transition-colors">
                  {place.name}
                </h3>
                <div className="flex items-center gap-2 text-sm text-[var(--muted)]">
                  <MapPin className="w-3 h-3" />
                  {place.neighborhood}
                </div>
              </div>
              <button
                onClick={() => toggleSavePlace(place.id)}
                className="p-2 rounded-lg hover:bg-[var(--surface)] transition-colors"
              >
                <Heart
                  className={`w-5 h-5 transition-colors ${
                    savedPlaces.includes(place.id) ? 'text-[var(--accent)] fill-[var(--accent)]' : 'text-[var(--muted)]'
                  }`}
                />
              </button>
            </div>
            
            <p className="text-sm text-[var(--text-secondary)] mb-4 line-clamp-2">
              {place.description}
            </p>
            
            <div className="flex items-center gap-4 text-sm mb-4">
              <div className="flex items-center gap-1">
                <Star className="w-4 h-4 text-yellow-500" fill="currentColor" />
                <span>{place.googleRating}</span>
              </div>
              <div className="flex items-center gap-1 text-[var(--muted)]">
                <Euro className="w-4 h-4" />
                <span>{place.priceRange}</span>
              </div>
              <span className="px-2 py-0.5 rounded-full bg-[var(--accent-soft)] text-[var(--accent)] text-xs">
                {place.category}
              </span>
            </div>
            
            <div className="flex items-center justify-between">
              <div className="flex gap-1">
                {place.vibe.slice(0, 2).map(v => (
                  <span key={v} className="text-xs px-2 py-1 rounded-full bg-[var(--surface)] text-[var(--muted)]">
                    {v}
                  </span>
                ))}
              </div>
              <div className="flex items-center gap-1 text-sm">
                <Heart className="w-3 h-3 text-[var(--accent)]" />
                <span className="text-[var(--accent)]">{place.romanticScore}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Events Component
function Events() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Upcoming Events</h2>
        <button className="text-sm text-[var(--accent)] hover:underline">View all</button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {events.map((event, i) => (
          <div
            key={event.id}
            className="glass rounded-2xl p-5 hover:bg-[var(--card-hover)] transition-all duration-200 animate-fade-in-up"
            style={{ animationDelay: `${i * 0.05}s` }}
          >
            <div className="flex items-start justify-between mb-3">
              <span className="px-3 py-1 rounded-full bg-[var(--accent-soft)] text-[var(--accent)] text-xs font-medium">
                {event.category}
              </span>
              <span className="text-sm text-[var(--muted)]">{event.price}</span>
            </div>
            
            <h3 className="font-semibold text-lg mb-2">{event.title}</h3>
            <p className="text-sm text-[var(--text-secondary)] mb-4">{event.description}</p>
            
            <div className="flex items-center gap-4 text-sm text-[var(--muted)]">
              <div className="flex items-center gap-1">
                <Calendar className="w-4 h-4" />
                <span>{event.date}</span>
              </div>
              <div className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                <span>{event.time}</span>
              </div>
              <div className="flex items-center gap-1">
                <Users className="w-4 h-4" />
                <span>{event.attendees}+</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Guides Component
function Guides() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold">Dating Guides</h2>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {guides.map((guide, i) => (
          <button
            key={guide.id}
            className="glass rounded-2xl p-5 text-left hover:bg-[var(--card-hover)] transition-all duration-200 group animate-fade-in-up"
            style={{ animationDelay: `${i * 0.05}s` }}
          >
            <span className="text-xs text-[var(--accent)] font-medium">{guide.category}</span>
            <h3 className="font-semibold text-lg mt-2 mb-2 group-hover:text-[var(--accent)] transition-colors">
              {guide.title}
            </h3>
            <p className="text-sm text-[var(--text-secondary)] mb-3">{guide.excerpt}</p>
            <div className="flex items-center gap-1 text-sm text-[var(--muted)]">
              <Clock className="w-4 h-4" />
              <span>{guide.readTime} read</span>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}

// Neighborhoods Component
function Neighborhoods() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Neighborhood Guide</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {neighborhoods.map((hood, i) => (
          <div
            key={hood.id}
            className="glass rounded-2xl p-5 hover:bg-[var(--card-hover)] transition-all duration-200 animate-fade-in-up"
            style={{ animationDelay: `${i * 0.05}s` }}
          >
            <div className="flex items-start justify-between mb-3">
              <h3 className="font-semibold text-lg">{hood.name}</h3>
              <span className="text-sm text-[var(--muted)]">{hood.avgPrice}</span>
            </div>
            
            <p className="text-sm text-[var(--text-secondary)] mb-4">{hood.description}</p>
            
            <div className="grid grid-cols-2 gap-3 text-sm">
              <div>
                <span className="text-[var(--muted)]">Dating</span>
                <div className="flex items-center gap-1 mt-1">
                  <div className="flex-1 h-1.5 bg-[var(--surface)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-[var(--accent)] rounded-full"
                      style={{ width: `${hood.datingScore * 10}%` }}
                    />
                  </div>
                  <span className="text-xs text-[var(--accent)]">{hood.datingScore}</span>
                </div>
              </div>
              <div>
                <span className="text-[var(--muted)]">Nightlife</span>
                <div className="flex items-center gap-1 mt-1">
                  <div className="flex-1 h-1.5 bg-[var(--surface)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-purple-500 rounded-full"
                      style={{ width: `${hood.nightlifeScore * 10}%` }}
                    />
                  </div>
                  <span className="text-xs text-purple-400">{hood.nightlifeScore}</span>
                </div>
              </div>
              <div>
                <span className="text-[var(--muted)]">Safety</span>
                <div className="flex items-center gap-1 mt-1">
                  <div className="flex-1 h-1.5 bg-[var(--surface)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-green-500 rounded-full"
                      style={{ width: `${hood.safetyScore * 10}%` }}
                    />
                  </div>
                  <span className="text-xs text-green-400">{hood.safetyScore}</span>
                </div>
              </div>
              <div>
                <span className="text-[var(--muted)]">Nomad</span>
                <div className="flex items-center gap-1 mt-1">
                  <div className="flex-1 h-1.5 bg-[var(--surface)] rounded-full overflow-hidden">
                    <div
                      className="h-full bg-blue-500 rounded-full"
                      style={{ width: `${hood.nomadScore * 10}%` }}
                    />
                  </div>
                  <span className="text-xs text-blue-400">{hood.nomadScore}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// Map Placeholder Component
function MapView() {
  return (
    <div className="space-y-6">
      <h2 className="text-xl font-bold">Explore Map</h2>
      
      <div className="glass rounded-2xl overflow-hidden">
        <div className="aspect-[16/9] bg-gradient-to-br from-[var(--surface)] to-[var(--card)] flex items-center justify-center">
          <div className="text-center p-8">
            <Map className="w-16 h-16 text-[var(--accent)] mx-auto mb-4 opacity-50" />
            <h3 className="text-lg font-semibold mb-2">Interactive Map Coming Soon</h3>
            <p className="text-[var(--muted)] text-sm max-w-md">
              We're integrating with mapping services to show you all the best spots in Lisbon.
              For now, check out the Directory section!
            </p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {places.slice(0, 4).map(place => (
          <div key={place.id} className="glass rounded-xl p-4 text-center">
            <MapPin className="w-5 h-5 text-[var(--accent)] mx-auto mb-2" />
            <h4 className="font-medium text-sm">{place.name}</h4>
            <p className="text-xs text-[var(--muted)]">{place.neighborhood}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// Main App Component
export default function App() {
  const [isDark, setIsDark] = useState(true);
  const [activeTab, setActiveTab] = useState('chat');
  const [showOnboarding, setShowOnboarding] = useState(true);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [preferences, setPreferencesState] = useState<UserPreferences>({
    onboardingComplete: false
  });
  const [savedPlaces, setSavedPlaces] = useState<string[]>([]);
  
  const setPreferences = (prefs: Partial<UserPreferences>) => {
    setPreferencesState(prev => ({ ...prev, ...prefs }));
  };
  
  const toggleSavePlace = (id: string) => {
    setSavedPlaces(prev => prev.includes(id) ? prev.filter(p => p !== id) : [...prev, id]);
  };
  
  const toggleTheme = () => {
    setIsDark(!isDark);
    document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
  };
  
  const navItems = [
    { id: 'chat', label: 'AI Chat', icon: MessageCircle },
    { id: 'directory', label: 'Directory', icon: Search },
    { id: 'events', label: 'Events', icon: Calendar },
    { id: 'guides', label: 'Guides', icon: BookOpen },
    { id: 'neighborhoods', label: 'Areas', icon: Navigation },
    { id: 'map', label: 'Map', icon: Map }
  ];
  
  return (
    <UserContext.Provider value={{ preferences, setPreferences, savedPlaces, toggleSavePlace }}>
      <div className="min-h-screen bg-[var(--bg)]">
        {showOnboarding && !preferences.onboardingComplete && (
          <Onboarding onComplete={() => setShowOnboarding(false)} />
        )}
        
        {/* Header */}
        <header className="sticky top-0 z-40 backdrop-blur-xl bg-[var(--bg)]/80 border-b border-[var(--border)]">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between h-16">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[var(--accent)] to-pink-400 flex items-center justify-center">
                  <Heart className="w-5 h-5 text-white" fill="white" />
                </div>
                <div>
                  <h1 className="font-bold text-lg">Lisbon Nomad Love</h1>
                  <p className="text-xs text-[var(--muted)] hidden sm:block">Your AI local friend</p>
                </div>
              </div>
              
              <div className="flex items-center gap-2">
                <button
                  onClick={toggleTheme}
                  className="p-2 rounded-xl hover:bg-[var(--surface)] transition-colors"
                  aria-label="Toggle theme"
                >
                  {isDark ? <Moon className="w-5 h-5" /> : <Sun className="w-5 h-5" />}
                </button>
                
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="p-2 rounded-xl hover:bg-[var(--surface)] transition-colors md:hidden"
                  aria-label="Toggle menu"
                >
                  {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
                </button>
              </div>
            </div>
          </div>
        </header>
        
        {/* Mobile Nav */}
        {mobileMenuOpen && (
          <nav className="md:hidden fixed inset-x-0 top-16 z-30 bg-[var(--bg)]/95 backdrop-blur-xl border-b border-[var(--border)] animate-fade-in">
            <div className="p-4 space-y-1">
              {navItems.map(item => (
                <button
                  key={item.id}
                  onClick={() => {
                    setActiveTab(item.id);
                    setMobileMenuOpen(false);
                  }}
                  className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-colors ${
                    activeTab === item.id
                      ? 'bg-[var(--accent-soft)] text-[var(--accent)]'
                      : 'text-[var(--text-secondary)] hover:bg-[var(--surface)]'
                  }`}
                >
                  <item.icon className="w-5 h-5" />
                  {item.label}
                </button>
              ))}
            </div>
          </nav>
        )}
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="flex gap-8">
            {/* Desktop Sidebar */}
            <aside className="hidden md:block w-56 shrink-0">
              <nav className="sticky top-24 space-y-1">
                {navItems.map(item => (
                  <button
                    key={item.id}
                    onClick={() => setActiveTab(item.id)}
                    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      activeTab === item.id
                        ? 'bg-[var(--accent-soft)] text-[var(--accent)] font-medium'
                        : 'text-[var(--text-secondary)] hover:bg-[var(--surface)] hover:text-[var(--text)]'
                    }`}
                  >
                    <item.icon className="w-5 h-5" />
                    {item.label}
                  </button>
                ))}
              </nav>
            </aside>
            
            {/* Main Content */}
            <main className="flex-1 min-w-0">
              {activeTab === 'chat' && <Chat />}
              {activeTab === 'directory' && <Directory />}
              {activeTab === 'events' && <Events />}
              {activeTab === 'guides' && <Guides />}
              {activeTab === 'neighborhoods' && <Neighborhoods />}
              {activeTab === 'map' && <MapView />}
            </main>
          </div>
        </div>
      </div>
    </UserContext.Provider>
  );
}
